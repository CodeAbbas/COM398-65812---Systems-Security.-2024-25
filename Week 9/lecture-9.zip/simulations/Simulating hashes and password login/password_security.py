import hashlib
import os
import time
import getpass
import sys

class PasswordSecuritySimulator:
    def __init__(self):
        self.database = {}  # Simulated user database {username: {'salt': salt, 'hash': hash_value}}
        self.current_user = None
    
    def clear_screen(self):
        """Clear the terminal screen based on OS."""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title):
        """Print a formatted header."""
        self.clear_screen()
        print("=" * 50)
        print(f"{title:^50}")
        print("=" * 50)
        print()
    
    def print_step(self, step_num, title):
        """Print a step header for visualization."""
        print(f"\n[Step {step_num}] {title}")
        print("-" * 50)
    
    def slow_print(self, text, delay=0.03):
        """Print text with a typing effect."""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        print()
    
    def display_progress(self, message, steps=10, delay=0.1):
        """Display a simple progress bar."""
        print(message, end=" ")
        for i in range(steps):
            sys.stdout.write("▓")
            sys.stdout.flush()
            time.sleep(delay)
        print(" Done!")
    
    def generate_salt(self):
        """Generate a random salt for a user."""
        return os.urandom(16).hex()[:16]  # 16 characters salt
    
    def hash_password(self, password, salt):
        """Hash a password with a salt using SHA-256."""
        # Combine password and salt
        salted_password = password + salt
        
        # Create hash using SHA-256
        hash_obj = hashlib.sha256(salted_password.encode())
        
        # Return hexadecimal hash
        return hash_obj.hexdigest()
    
    def signup(self):
        """Simulate the signup process."""
        self.print_header("PASSWORD SECURITY 101 - SIGN UP PROCESS")
        
        print("This simulation will show how your password is securely stored.")
        print("Let's create a new account!\n")
        
        # Step 1: Get credentials
        username = input("Enter a username: ")
        
        # Check if username exists
        if username in self.database:
            print("Username already exists! Press Enter to continue...")
            input()
            return
        
        password = getpass.getpass("Enter a password: ")
        
        # Step 2: Show password collection
        self.print_step(1, "Collecting Password Input")
        masked_password = password[0] + "*" * (len(password) - 2) + password[-1] if len(password) > 2 else password
        self.slow_print(f"User entered password: {masked_password}")
        time.sleep(1)
        
        # Step 3: Generate Salt
        self.print_step(2, "Generating Random Salt")
        salt = self.generate_salt()
        self.slow_print(f"Generated salt: {salt}")
        self.slow_print("This unique salt ensures that even identical passwords result in different hashes.")
        time.sleep(1)
        
        # Step 4: Combine and Hash
        self.print_step(3, "Combining Password with Salt")
        salted_password = password + salt
        masked_salted = masked_password + " + " + salt
        self.slow_print(f"Combined value: {masked_salted}")
        time.sleep(1)
        
        # Step 5: Hash the combined value
        self.print_step(4, "Hashing the Combined Value")
        self.slow_print("Running the password+salt through a one-way hash function...")
        self.display_progress("Processing", 20, 0.05)
        
        password_hash = self.hash_password(password, salt)
        self.slow_print(f"Resulting hash: {password_hash}")
        self.slow_print("This hash cannot be reversed to obtain the original password.")
        time.sleep(1)
        
        # Step 6: Store in Database
        self.print_step(5, "Storing in Database")
        self.slow_print("Saving user information to the database...")
        self.display_progress("Saving", 10, 0.1)
        
        # Store in our simulated database
        self.database[username] = {
            'salt': salt,
            'hash': password_hash
        }
        
        # Show the database
        print("\nDatabase Entry:")
        print(f"| {'Username':<15} | {'Salt':<16} | {'Password Hash':<64} |")
        print(f"| {'-'*15} | {'-'*16} | {'-'*64} |")
        for user, data in self.database.items():
            print(f"| {user:<15} | {data['salt']:<16} | {data['hash']:<64} |")
        
        self.slow_print("\nNotice that your actual password is never stored anywhere!")
        self.current_user = username
        
        input("\nPress Enter to continue to login simulation...")
    
    def login(self, use_wrong_password=False):
        """Simulate the login process."""
        self.print_header("PASSWORD SECURITY 101 - LOGIN PROCESS")
        
        if not self.database:
            print("No users in the database. Please sign up first.")
            input("Press Enter to continue...")
            return
        
        print("This simulation will show how your password is verified during login.")
        print("Let's log in to your account!\n")
        
        # Step 1: Collect credentials
        if self.current_user:
            username = self.current_user
            print(f"Username: {username} (auto-filled from signup)")
        else:
            username = input("Enter your username: ")
        
        # Check if username exists
        if username not in self.database:
            print("Username not found! Please sign up first.")
            input("Press Enter to continue...")
            return
        
        # Get password
        if use_wrong_password:
            print("Simulating a login with incorrect password...")
            password = getpass.getpass("Enter a wrong password: ")
        else:
            password = getpass.getpass("Enter your password: ")
        
        # Step 2: Show login attempt
        self.print_step(1, "Collecting Login Credentials")
        masked_password = password[0] + "*" * (len(password) - 2) + password[-1] if len(password) > 2 else password
        self.slow_print(f"User entered username: {username}")
        self.slow_print(f"User entered password: {masked_password}")
        time.sleep(1)
        
        # Step 3: Retrieve salt
        self.print_step(2, "Retrieving User's Salt")
        user_salt = self.database[username]['salt']
        self.slow_print(f"Retrieved salt from database: {user_salt}")
        self.slow_print("The salt is stored in plain text because it's unique per user and not secret.")
        time.sleep(1)
        
        # Step 4: Hash login password
        self.print_step(3, "Hashing the Login Password with Salt")
        self.slow_print(f"Combining entered password with retrieved salt...")
        self.slow_print(f"Running the combined value through the same hash function...")
        self.display_progress("Processing", 20, 0.05)
        
        login_hash = self.hash_password(password, user_salt)
        self.slow_print(f"Generated hash: {login_hash}")
        time.sleep(1)
        
        # Step 5: Compare hashes
        self.print_step(4, "Comparing Hash Values")
        stored_hash = self.database[username]['hash']
        
        self.slow_print("Comparing generated hash with stored hash:")
        print(f"Stored hash:  {stored_hash}")
        print(f"Login hash:   {login_hash}")
        print(f"Hash match:   {stored_hash == login_hash}")
        time.sleep(1)
        
        # Step 6: Authentication result
        self.print_step(5, "Authentication Result")
        if stored_hash == login_hash:
            self.slow_print("✅ LOGIN SUCCESSFUL!")
            self.slow_print("The hashes match exactly, so the password must be correct.")
        else:
            self.slow_print("❌ LOGIN FAILED!")
            self.slow_print("The hashes don't match, so the password is incorrect.")
            self.slow_print("\nNotice that the system never needed to know your actual password - it only compares hash values.")
        
        input("\nPress Enter to return to main menu...")
    
    def show_database(self):
        """Display the current database contents."""
        self.print_header("PASSWORD SECURITY 101 - DATABASE VIEW")
        
        if not self.database:
            print("Database is empty. Please sign up first.")
            input("Press Enter to continue...")
            return
        
        print("Current Database Contents:\n")
        print(f"| {'Username':<15} | {'Salt':<16} | {'Password Hash':<64} |")
        print(f"| {'-'*15} | {'-'*16} | {'-'*64} |")
        for user, data in self.database.items():
            print(f"| {user:<15} | {data['salt']:<16} | {data['hash']:<64} |")
        
        print("\nNOTICE: The actual passwords are not stored anywhere in the database!")
        print("When a user logs in, the system:")
        print("1. Retrieves their salt")
        print("2. Combines it with the entered password")
        print("3. Hashes the combination")
        print("4. Compares this hash with the stored hash")
        
        input("\nPress Enter to return to main menu...")
    
    def show_info(self):
        """Display educational information about password security."""
        self.print_header("PASSWORD SECURITY 101 - EDUCATIONAL INFO")
        
        print("HOW PASSWORDS ARE SECURELY STORED\n")
        self.slow_print("Websites and applications never store your actual password in plain text.")
        self.slow_print("Instead, they use a process called 'hashing' and 'salting':\n")
        
        print("1. PASSWORD HASHING")
        print("   - A hash function converts your password into a fixed-length string of characters")
        print("   - This process is one-way, meaning the hash cannot be converted back to the original password")
        print("   - Even a tiny change in the input creates a completely different hash output\n")
        
        print("2. SALTING")
        print("   - A 'salt' is a random string that is added to your password before hashing")
        print("   - Each user gets a unique salt, stored alongside their password hash")
        print("   - This prevents attackers from using 'rainbow tables' (pre-computed hash dictionaries)")
        print("   - It also ensures that two users with the same password will have different hash values\n")
        
        print("3. VERIFICATION")
        print("   - When you log in, the system retrieves your salt from the database")
        print("   - It adds this salt to the password you entered and hashes the combination")
        print("   - If the resulting hash matches the stored hash, access is granted")
        print("   - The system never needs to know your actual password\n")
        
        print("4. PASSWORD RESETS")
        print("   - This is why systems can't tell you your old password when you forget it")
        print("   - They don't know it! They only know the hash")
        print("   - Instead, they verify your identity another way and let you create a new password\n")
        
        input("Press Enter to return to main menu...")
    
    def menu(self):
        """Display main menu and handle user choices."""
        while True:
            self.print_header("PASSWORD SECURITY 101 - MAIN MENU")
            
            print("1. Sign Up (Create New Account)")
            print("2. Log In (With Correct Password)")
            print("3. Try Login with Wrong Password")
            print("4. View Database")
            print("5. Educational Information")
            print("6. Exit\n")
            
            choice = input("Enter your choice (1-6): ")
            
            if choice == '1':
                self.signup()
            elif choice == '2':
                self.login(use_wrong_password=False)
            elif choice == '3':
                self.login(use_wrong_password=True)
            elif choice == '4':
                self.show_database()
            elif choice == '5':
                self.show_info()
            elif choice == '6':
                self.print_header("Thank You for Using the Password Security Simulator!")
                print("Remember: Never reuse passwords across different sites!")
                print("Use a password manager and enable two-factor authentication when possible.")
                time.sleep(2)
                break
            else:
                print("Invalid choice. Please try again.")
                time.sleep(1)


if __name__ == "__main__":
    simulator = PasswordSecuritySimulator()
    simulator.menu()
