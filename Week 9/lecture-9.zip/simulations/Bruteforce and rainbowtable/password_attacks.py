import hashlib
import time
import random
import os
import sys
from datetime import datetime

class PasswordAttackSimulator:
    def __init__(self):
        self.common_passwords = [
            "password", "123456", "qwerty", "admin", "welcome",
            "login", "abc123", "letmein", "monkey", "1234567",
            "football", "iloveyou", "123123", "111111", "dragon",
            "sunshine", "master", "666666", "qwertyuiop", "123321"
        ]
        # Our target username/password for this simulation
        self.target_user = {"username": "johnsmith", "password": "sunshine"}
        self.rainbow_table = {}  # Will be populated during initialization
        self.salted_users = {}   # Will store salted password hashes
    
    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title):
        """Print a formatted header."""
        self.clear_screen()
        width = 70
        print("=" * width)
        print(f"{title:^{width}}")
        print("=" * width)
        print()
    
    def slow_print(self, text, delay=0.03):
        """Print text with a typing effect."""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        print()
    
    def hash_password(self, password):
        """Simple hash function for passwords (no salt)."""
        hash_obj = hashlib.sha256(password.encode())
        return hash_obj.hexdigest()
    
    def hash_password_with_salt(self, password, salt):
        """Hash a password with a salt."""
        salted_password = password + salt
        hash_obj = hashlib.sha256(salted_password.encode())
        return hash_obj.hexdigest()
    
    def generate_salt(self):
        """Generate a random salt."""
        return os.urandom(8).hex()
    
    def initialize_rainbow_table(self):
        """Generate a rainbow table with common passwords."""
        self.print_header("GENERATING RAINBOW TABLE")
        print("A rainbow table is a precomputed table of password hashes.")
        print("Attackers create these tables for common passwords to quickly crack hashes.\n")
        
        print("Generating hashes for common passwords:")
        for password in self.common_passwords:
            hash_value = self.hash_password(password)
            self.rainbow_table[hash_value] = password
            
            print(f"Password: {password:12} -> Hash: {hash_value[:20]}...")
            time.sleep(0.2)
        
        print(f"\nRainbow table complete with {len(self.rainbow_table)} entries.")
        print("In real attacks, these tables contain millions or billions of entries.")
        input("\nPress Enter to continue...")
    
    def initialize_user_database(self):
        """Create a database of users with both unsalted and salted hashes."""
        # Create unsalted hash for our target user
        password_hash = self.hash_password(self.target_user["password"])
        self.target_user["hash"] = password_hash
        
        # Create salted hash versions
        salt = self.generate_salt()
        salted_hash = self.hash_password_with_salt(self.target_user["password"], salt)
        
        self.salted_users = {
            self.target_user["username"]: {
                "salt": salt,
                "salted_hash": salted_hash
            }
        }
    
    def simulate_rainbow_table_attack(self):
        """Simulate a rainbow table attack on an unsalted password hash."""
        self.print_header("RAINBOW TABLE ATTACK SIMULATION")
        
        print(f"TARGET: User '{self.target_user['username']}'\n")
        print("SCENARIO: A database has been breached, and the attacker has obtained password hashes.")
        print("The passwords were hashed but NOT salted.\n")
        
        print("STOLEN DATA:")
        print(f"Username: {self.target_user['username']}")
        print(f"Password Hash: {self.target_user['hash']}")
        print("\nAttacker begins rainbow table lookup...")
        
        # Simulate looking up the hash in the rainbow table
        start_time = time.time()
        
        found = False
        checked = 0
        
        # Simulate checking through the rainbow table
        for hash_value, password in self.rainbow_table.items():
            checked += 1
            time.sleep(0.1)  # Slow down for demonstration
            
            # Show progress
            print(f"Checking hash: {hash_value[:20]}... against target: {self.target_user['hash'][:20]}...", end="\r")
            
            if hash_value == self.target_user["hash"]:
                found = True
                break
        
        end_time = time.time()
        elapsed = end_time - start_time
        
        print("\n")
        if found:
            print("✓ PASSWORD CRACKED!")
            print(f"Password found: '{password}'")
            print(f"Time taken: {elapsed:.2f} seconds")
            print(f"Entries checked: {checked} out of {len(self.rainbow_table)}")
            print("\nThis was fast because:")
            print("1. The password was common and in the rainbow table")
            print("2. The hash had NO salt, so lookup was trivial")
        else:
            print("× Password not found in rainbow table.")
            print("In this case, the attacker would need to try other methods.")
        
        input("\nPress Enter to continue to the next simulation...")
    
    def simulate_rainbow_table_with_salt(self):
        """Show why salting defeats rainbow tables."""
        self.print_header("SALTED PASSWORDS VS RAINBOW TABLES")
        
        print("Now let's see what happens when passwords are properly salted:")
        print(f"TARGET: User '{self.target_user['username']}'\n")
        
        user_salt = self.salted_users[self.target_user["username"]]["salt"]
        user_salted_hash = self.salted_users[self.target_user["username"]]["salted_hash"]
        
        print("STOLEN DATA:")
        print(f"Username: {self.target_user['username']}")
        print(f"Salt: {user_salt}")
        print(f"Salted Hash: {user_salted_hash}")
        
        print("\nAttacker attempts rainbow table lookup...")
        time.sleep(1)
        
        print("\n× RAINBOW TABLE ATTACK FAILED!")
        print("The salt makes the rainbow table useless because:")
        print("1. Each user has a unique salt, so the same password hashes differently for each user")
        print("2. The attacker would need a separate rainbow table for each possible salt")
        print("3. With 16-character hex salts, there are 2⁶⁴ possible salt values")
        print("\nRainbow tables become impractical against properly salted passwords.")
        
        input("\nPress Enter to continue to the next simulation...")
    
    def simulate_brute_force(self):
        """Simulate a brute force attack trying every possible password."""
        self.print_header("BRUTE FORCE ATTACK SIMULATION")
        
        print("In a brute force attack, the attacker tries every possible password combination.")
        print("This is a last resort method and very time-consuming, but eventually successful.\n")
        
        # Set up for demonstration (we'll use a very short password space)
        charset = "abcdefghijklmnopqrstuvwxyz"  # Only lowercase for demo
        max_length = 3  # Only try passwords up to 3 chars for demonstration
        target_password = "cat"  # Short password for demo purposes
        
        print(f"Target password: {target_password}")
        print(f"Character set: {charset}")
        print(f"Will try all combinations up to {max_length} characters")
        
        # Calculate total possibilities for information
        total_possibilities = 0
        for length in range(1, max_length + 1):
            total_possibilities += len(charset) ** length
        
        print(f"Total combinations to try: {total_possibilities:,}")
        
        input("\nPress Enter to start the brute force attack...")
        
        # Simulate brute force attack
        found = False
        attempts = 0
        start_time = time.time()
        
        # Generate and check 1-character passwords
        print("\nTrying 1-character passwords:")
        for c in charset:
            attempts += 1
            print(f"Trying: {c}", end="\r")
            time.sleep(0.05)
            
            if c == target_password:
                found = True
                break
        
        if not found:
            # Generate and check 2-character passwords
            print("\nTrying 2-character passwords:")
            for c1 in charset:
                for c2 in charset:
                    password = c1 + c2
                    attempts += 1
                    
                    # Print every 10th attempt to avoid console spam
                    if attempts % 10 == 0:
                        print(f"Trying: {password}", end="\r")
                    time.sleep(0.01)
                    
                    if password == target_password:
                        found = True
                        break
                if found:
                    break
        
        if not found:
            # Generate and check 3-character passwords
            print("\nTrying 3-character passwords:")
            for c1 in charset:
                for c2 in charset:
                    for c3 in charset:
                        password = c1 + c2 + c3
                        attempts += 1
                        
                        # Print every 100th attempt to avoid console spam
                        if attempts % 100 == 0:
                            print(f"Trying: {password}", end="\r")
                        time.sleep(0.001)
                        
                        if password == target_password:
                            found = True
                            break
                    if found:
                        break
                if found:
                    break
        
        end_time = time.time()
        elapsed = end_time - start_time
        
        print("\n")
        if found:
            print(f"✓ PASSWORD CRACKED: '{target_password}'")
            print(f"Attempts: {attempts:,} out of {total_possibilities:,} possible combinations")
            print(f"Time taken: {elapsed:.2f} seconds")
            
            print("\nWhat this means:")
            print("1. Short passwords can be cracked quickly")
            print("2. Each added character exponentially increases the cracking time")
            print("3. For our 26-letter charset, each extra character multiplies possibilities by 26")
            
            # Estimate time for longer passwords
            print("\nEstimated cracking times at this speed:")
            base_time = elapsed / attempts
            for length in range(4, 11):
                combinations = len(charset) ** length
                est_time = combinations * base_time
                time_str = self.format_time(est_time)
                print(f"{length}-character password: {time_str}")
        else:
            print("× Something went wrong. Password not found.")
        
        input("\nPress Enter to continue...")
    
    def format_time(self, seconds):
        """Format seconds into a readable time string."""
        if seconds < 60:
            return f"{seconds:.2f} seconds"
        elif seconds < 3600:
            return f"{seconds/60:.2f} minutes"
        elif seconds < 86400:
            return f"{seconds/3600:.2f} hours"
        elif seconds < 31536000:
            return f"{seconds/86400:.2f} days"
        elif seconds < 315360000:  # 10 years
            return f"{seconds/31536000:.2f} years"
        else:
            return "centuries"
    
    def show_defenses(self):
        """Show password security best practices."""
        self.print_header("PASSWORD SECURITY DEFENSES")
        
        print("BEST PRACTICES TO PROTECT AGAINST ATTACKS:\n")
        
        print("FOR USERS:")
        print("1. Use long, complex passwords (15+ characters)")
        print("   - Each additional character exponentially increases cracking time")
        print("2. Use a unique password for each website")
        print("   - If one site is breached, others remain secure")
        print("3. Consider using a password manager")
        print("   - Helps generate and store strong, unique passwords")
        print("4. Enable two-factor authentication when available")
        print("   - Adds a second layer of security beyond just the password")
        
        print("\nFOR DEVELOPERS:")
        print("1. Always salt and hash passwords")
        print("   - Use a unique salt for each user")
        print("   - Use strong hashing algorithms (bcrypt, Argon2, PBKDF2)")
        print("2. Implement rate limiting for login attempts")
        print("   - Prevents rapid brute force attempts")
        print("3. Use adaptive hashing functions")
        print("   - Can be configured to be intentionally slow to compute")
        print("   - Helps resist brute force attacks")
        print("4. Regularly audit security practices")
        print("   - Stay updated on the latest security recommendations")
        
        input("\nPress Enter to return to the main menu...")
    
    def menu(self):
        """Display the main menu and handle user choices."""
        while True:
            self.print_header("PASSWORD ATTACK SIMULATION")
            
            print("This program simulates common password cracking techniques")
            print("and demonstrates why proper security measures are important.\n")
            
            print("1. Initialize System & Rainbow Table")
            print("2. Rainbow Table Attack Simulation")
            print("3. Why Salting Defeats Rainbow Tables")
            print("4. Brute Force Attack Simulation")
            print("5. Password Security Best Practices")
            print("6. Exit\n")
            
            choice = input("Enter your choice (1-6): ")
            
            if choice == '1':
                self.initialize_rainbow_table()
                self.initialize_user_database()
            elif choice == '2':
                if not self.rainbow_table:
                    print("Please initialize the system first (option 1)")
                    time.sleep(2)
                    continue
                self.simulate_rainbow_table_attack()
            elif choice == '3':
                if not self.rainbow_table or not self.salted_users:
                    print("Please initialize the system first (option 1)")
                    time.sleep(2)
                    continue
                self.simulate_rainbow_table_with_salt()
            elif choice == '4':
                self.simulate_brute_force()
            elif choice == '5':
                self.show_defenses()
            elif choice == '6':
                self.print_header("Thank You!")
                print("Remember: The best defense is using strong, unique passwords")
                print("and enabling two-factor authentication when possible.")
                time.sleep(2)
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 6.")
                time.sleep(1)

if __name__ == "__main__":
    simulator = PasswordAttackSimulator()
    simulator.menu()
