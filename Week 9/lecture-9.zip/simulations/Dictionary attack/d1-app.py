import hashlib
import time
import random
import string
from tqdm import tqdm

class PasswordSecurityTester:
    def __init__(self):
        # Dictionary of common passwords
        self.common_passwords = [
            "password123", "qwerty123", "welcome1",
            "admin1234", "letmein12", "abc123456",
            "monkey123", "dragon123", "baseball1",
            "football1", "master123", "hello1234",
            "shadow123", "jennifer1", "hunter123",
            "killer123", "soccer123", "superman1",
            "pokemon12", "trustno1"
        ]
    
    def is_dictionary_password(self, password):
        """Check if the password is in the dictionary"""
        return password in self.common_passwords
    
    def generate_hash(self, password):
        """Generate SHA-256 hash of password"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def crack_password(self, target_hash):
        """Attempt to crack the password using dictionary attack"""
        total_passwords = len(self.common_passwords)
        
        print("\nStarting dictionary attack simulation...")
        print("Progress:")
        
        for idx, test_password in enumerate(tqdm(self.common_passwords, desc="Testing passwords", 
                                               bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')):
            test_hash = self.generate_hash(test_password)
            
            # Simulate processing time for demonstration
            time.sleep(0.2)
            
            if test_hash == target_hash:
                return True, test_password, idx + 1
                
        return False, None, total_passwords

def main():
    tester = PasswordSecurityTester()
    
    print("Password Security Testing Demonstration")
    print("======================================")
    print("\nThis demo will:")
    print("1. Check if your password is in a common password dictionary")
    print("2. If found, demonstrate how quickly it can be cracked")
    print("3. Show the cracking process with a progress bar")
    print("\nNote: This is for educational purposes to demonstrate password security.")
    
    while True:
        # Get password from user
        password = input("\nEnter a password to test (or 'quit' to exit): ")
        
        if password.lower() == 'quit':
            break
            
        if len(password) < 6:
            print("\n⚠️ Password is too short. Please use at least 6 characters.")
            continue
            
        # Check if it's a dictionary password
        is_common = tester.is_dictionary_password(password)
        
        if not is_common:
            print("\n✓ Good news! Your password was not found in our dictionary.")
            print("However, this is just a small demo dictionary. Real attacks use much larger dictionaries.")
            continue
            
        print("\n⚠️ Warning: Your password was found in the common password dictionary!")
        
        # Ask if user wants to see cracking demonstration
        show_demo = input("\nWould you like to see how quickly this password could be cracked? (y/n): ")
        
        if show_demo.lower() != 'y':
            continue
            
        # Demonstrate cracking
        target_hash = tester.generate_hash(password)
        print("\nPassword hash:", target_hash)
        
        start_time = time.time()
        success, cracked_password, attempts = tester.crack_password(target_hash)
        end_time = time.time()
        
        if success:
            print("\n❌ Password cracked!")
            print(f"Attempts needed: {attempts} out of {len(tester.common_passwords)}")
            print(f"Time taken: {end_time - start_time:.2f} seconds")
            print("\nThis demonstrates why using common passwords is unsafe.")
            print("Tips for stronger passwords:")
            print("- Use a mix of letters, numbers, and symbols")
            print("- Make it longer (12+ characters)")
            print("- Avoid common words and patterns")
            print("- Use a unique password for each account")
        else:
            print("\nSomething went wrong in the demonstration.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nProgram terminated by user.")
    except Exception as e:
        print(f"\n\nAn error occurred: {str(e)}")
    finally:
        print("\nThank you for using the password security demonstration!")
