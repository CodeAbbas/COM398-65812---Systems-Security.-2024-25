import hashlib
import time
from tqdm import tqdm

class PasswordSecurityTester:
    def __init__(self):
        self.dictionary = []
    
    def set_dictionary(self, wordlist):
        """Set custom dictionary from user input"""
        self.dictionary = wordlist
    
    def is_dictionary_password(self, password):
        """Check if the password is in the dictionary"""
        return password in self.dictionary
    
    def generate_hash(self, password):
        """Generate SHA-256 hash of password"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def crack_password(self, target_hash):
        """Attempt to crack the password using dictionary attack"""
        total_passwords = len(self.dictionary)
        
        print("\nStarting dictionary attack simulation...")
        print("Progress:")
        
        for idx, test_password in enumerate(tqdm(self.dictionary, desc="Testing passwords", 
                                               bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')):
            test_hash = self.generate_hash(test_password)
            
            # Simulate processing time for demonstration
            time.sleep(0.1)
            
            if test_hash == target_hash:
                return True, test_password, idx + 1
                
        return False, None, total_passwords

def get_custom_dictionary():
    """Get custom dictionary from user input"""
    print("\nCreate your custom dictionary:")
    print("Enter one password per line. Enter an empty line when done.")
    
    wordlist = []
    while True:
        word = input(f"Word {len(wordlist) + 1}: ").strip()
        if not word:
            if not wordlist:
                print("Dictionary cannot be empty. Please enter at least one word.")
                continue
            break
        wordlist.append(word)
    
    return wordlist

def main():
    tester = PasswordSecurityTester()
    
    print("Custom Dictionary Password Security Testing")
    print("=========================================")
    
    # Get custom dictionary
    print("\nFirst, let's create your dictionary of passwords to test against.")
    wordlist = get_custom_dictionary()
    tester.set_dictionary(wordlist)
    
    print(f"\nDictionary created with {len(wordlist)} words!")
    
    while True:
        # Get password from user
        print("\n" + "="*50)
        password = input("\nEnter a password to test (or 'quit' to exit): ")
        
        if password.lower() == 'quit':
            break
            
        if len(password) < 1:
            print("\n⚠️ Password cannot be empty.")
            continue
            
        # Check if it's a dictionary password
        is_common = tester.is_dictionary_password(password)
        
        if not is_common:
            print("\n✓ Password was not found in your dictionary.")
            continue
            
        print("\n⚠️ Warning: Password was found in your dictionary!")
        
        # Ask if user wants to see cracking demonstration
        show_demo = input("\nWould you like to see how quickly this password could be cracked? (y/n): ")
        
        if show_demo.lower() != 'y':
            continue
            
        # Demonstrate cracking
        target_hash = tester.generate_hash(password)
        print("\nPassword hash:", target_hash)
        
        start_time = time.time()
        success, cracked_password, attempts = tester.crack_password(target_hash)
        end_time = time.time()
        
        if success:
            print("\n❌ Password cracked!")
            print(f"Attempts needed: {attempts} out of {len(tester.dictionary)}")
            print(f"Time taken: {end_time - start_time:.2f} seconds")
            print(f"Position in dictionary: {attempts}")
            print("\nThis demonstrates why using passwords from known wordlists is unsafe.")
        else:
            print("\nError: Password not cracked (this shouldn't happen for a found password)")

def load_dictionary_from_file(filename):
    """Load dictionary from a file"""
    try:
        with open(filename, 'r') as file:
            return [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        return None
    except Exception as e:
        print(f"Error reading file: {str(e)}")
        return None

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nProgram terminated by user.")
    except Exception as e:
        print(f"\n\nAn error occurred: {str(e)}")
    finally:
        print("\nThank you for using the password security demonstration!")
