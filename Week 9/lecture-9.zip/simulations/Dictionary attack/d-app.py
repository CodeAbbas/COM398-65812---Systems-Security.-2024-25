import hashlib
import time
import random
import string
from tqdm import tqdm

class PasswordSecurityDemo:
    def __init__(self):
        # Sample dictionary of common passwords (in reality this would be much larger)
        self.common_passwords = [
            "password123", "qwerty123", "welcome1",
            "admin1234", "letmein12", "abc123456",
            "monkey123", "dragon123", "baseball1",
            "football1", "master123", "hello1234",
            "shadow123", "jennifer1", "hunter123",
            "killer123", "soccer123", "superman1",
            "pokemon12", "trustno1"
        ]
        
        # Store password hashes
        self.password_database = {}
        
    def generate_hash(self, password):
        """Generate SHA-256 hash of password"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def setup_demo_accounts(self):
        """Create demo accounts with passwords from the dictionary"""
        usernames = [f"user{i}" for i in range(1, 6)]
        for username in usernames:
            password = random.choice(self.common_passwords)
            self.password_database[username] = {
                'hash': self.generate_hash(password),
                'original': password  # Only for demonstration purposes
            }
        return usernames
    
    def dictionary_attack(self, target_hash):
        """Simulate a dictionary attack on a password hash"""
        total_passwords = len(self.common_passwords)
        
        print("\nStarting dictionary attack...")
        for idx, test_password in enumerate(tqdm(self.common_passwords, desc="Testing passwords")):
            test_hash = self.generate_hash(test_password)
            
            # Simulate some processing time
            time.sleep(0.1)
            
            if test_hash == target_hash:
                return True, test_password, idx + 1
                
        return False, None, total_passwords

def main():
    # Initialize the demo
    demo = PasswordSecurityDemo()
    
    # Setup demo accounts
    print("Setting up demo accounts...")
    usernames = demo.setup_demo_accounts()
    
    print("\nDemo Accounts Created:")
    print("-" * 40)
    for username in usernames:
        print(f"Username: {username}")
        print(f"Original Password: {demo.password_database[username]['original']}")
        print(f"Password Hash: {demo.password_database[username]['hash'][:20]}...")
        print("-" * 40)
    
    # Demonstrate dictionary attack
    print("\nDemonstrating dictionary attack...")
    for username in usernames:
        target_hash = demo.password_database[username]['hash']
        print(f"\nAttempting to crack password for {username}")
        
        start_time = time.time()
        success, cracked_password, attempts = demo.dictionary_attack(target_hash)
        end_time = time.time()
        
        if success:
            print(f"\n✓ Password cracked successfully!")
            print(f"Original password: {demo.password_database[username]['original']}")
            print(f"Cracked password: {cracked_password}")
            print(f"Attempts needed: {attempts}")
            print(f"Time taken: {end_time - start_time:.2f} seconds")
        else:
            print(f"\n✗ Password not found in dictionary")
            print(f"Attempts made: {attempts}")
            print(f"Time taken: {end_time - start_time:.2f} seconds")

if __name__ == "__main__":
    main()
