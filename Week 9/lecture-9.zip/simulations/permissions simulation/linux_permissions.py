import os
import time
import sys
from datetime import datetime

class LinuxPermissionsSimulator:
    def __init__(self):
        # Initialize file system
        self.file_system = {
            "hello.txt": {
                "type": "file",
                "content": "Hello World!",
                "owner": "alice",
                "group": "users",
                "permissions": 0o644  # rw-r--r--
            },
            "script.sh": {
                "type": "file",
                "content": "#!/bin/bash\necho 'This script is running!'\nexit 0",
                "owner": "alice",
                "group": "users",
                "permissions": 0o755  # rwxr-xr-x
            },
            "private_notes.txt": {
                "type": "file",
                "content": "These are my private notes.",
                "owner": "alice",
                "group": "users",
                "permissions": 0o600  # rw-------
            },
            "projects": {
                "type": "directory",
                "contents": ["project1.txt", "project2.txt"],
                "owner": "alice",
                "group": "developers",
                "permissions": 0o750  # rwxr-x---
            },
            "project1.txt": {
                "type": "file",
                "content": "Project 1 data",
                "owner": "alice",
                "group": "developers",
                "permissions": 0o640  # rw-r-----
            },
            "project2.txt": {
                "type": "file",
                "content": "Project 2 data",
                "owner": "bob",
                "group": "developers",
                "permissions": 0o644  # rw-r--r--
            },
            "shared": {
                "type": "directory",
                "contents": ["shared_doc.txt"],
                "owner": "alice",
                "group": "users",
                "permissions": 0o777  # rwxrwxrwx
            },
            "shared_doc.txt": {
                "type": "file", 
                "content": "This is a shared document that anyone can edit.",
                "owner": "alice",
                "group": "users",
                "permissions": 0o666  # rw-rw-rw-
            }
        }
        
        # Users and groups
        self.users = {
            "alice": {"groups": ["users", "developers", "sudo"]},
            "bob": {"groups": ["users", "developers"]},
            "carol": {"groups": ["users"]},
            "root": {"groups": ["root", "sudo"]}
        }
        
        # Current user and working directory
        self.current_user = "alice"
        self.current_directory = "/"
    
    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title):
        """Print a formatted header."""
        self.clear_screen()
        width = 70
        print("=" * width)
        print(f"{title:^{width}}")
        print("=" * width)
        print()
    
    def slow_print(self, text, delay=0.02):
        """Print text with a typing effect."""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        print()
    
    def octal_to_rwx(self, octal_permissions):
        """Convert octal permission to rwx string format."""
        result = ""
        # Process each octal digit (user, group, others)
        for digit in oct(octal_permissions)[-3:]:
            # Convert the octal digit to binary, which gives us rwx
            binary = bin(int(digit))[2:].zfill(3)
            # Map binary digits to rwx characters
            for bit in binary:
                if bit == "1":
                    if len(result) % 3 == 0:
                        result += "r"
                    elif len(result) % 3 == 1:
                        result += "w"
                    else:
                        result += "x"
                else:
                    result += "-"
        return result
    
    def rwx_to_octal(self, rwx_permissions):
        """Convert rwx string format to octal permission."""
        if len(rwx_permissions) != 9:
            return None
        
        octal = 0
        value_map = {'r': 4, 'w': 2, 'x': 1, '-': 0}
        
        # Process each character trio (user, group, others)
        for i in range(0, 9, 3):
            trio_value = 0
            for j in range(3):
                if rwx_permissions[i+j] in value_map:
                    trio_value += value_map[rwx_permissions[i+j]]
            octal = octal * 10 + trio_value
        
        return octal
    
    def switch_user(self):
        """Change the current user."""
        self.print_header("SWITCH USER")
        
        print(f"Current user: {self.current_user}")
        print("\nAvailable users:")
        for user in self.users:
            groups = ", ".join(self.users[user]["groups"])
            print(f"- {user} (Groups: {groups})")
        
        new_user = input("\nSwitch to user (or press Enter to cancel): ")
        
        if new_user in self.users:
            self.current_user = new_user
            print(f"\nSwitched to user: {self.current_user}")
        elif new_user:
            print(f"\nUser '{new_user}' does not exist.")
        
        input("\nPress Enter to continue...")
    
    def list_files(self):
        """List files with their permissions."""
        self.print_header("FILE LISTING (ls -l)")
        
        print(f"Current user: {self.current_user}")
        print(f"Current directory: {self.current_directory}")
        print("\nFile Listing:")
        
        print("Permission    Owner    Group     Size  Name")
        print("-" * 50)
        
        for name, details in self.file_system.items():
            # Convert octal permission to rwx format
            permissions = self.octal_to_rwx(details["permissions"])
            
            # Add directory identifier if applicable
            if details["type"] == "directory":
                permissions = "d" + permissions
            else:
                permissions = "-" + permissions
            
            # Calculate size (for simulation)
            if details["type"] == "file":
                size = len(details["content"])
            else:
                size = 4096  # Typical directory size
            
            print(f"{permissions}  {details['owner']:<8} {details['group']:<8} {size:5}  {name}")
        
        input("\nPress Enter to continue...")
    
    def explain_permissions(self):
        """Explain the Linux permission system."""
        self.print_header("LINUX PERMISSIONS EXPLAINED")
        
        print("UNIX/Linux file permissions consist of three permission types:")
        print("  r (read): Permission to read a file or list directory contents")
        print("  w (write): Permission to modify a file or create/delete files in a directory")
        print("  x (execute): Permission to run a file as a program or access a directory")
        
        print("\nPermissions are assigned to three categories of users:")
        print("  Owner (u): The user who created or owns the file")
        print("  Group (g): Users who are members of the file's group")
        print("  Others (o): All other users on the system")
        
        print("\nNUMERIC REPRESENTATION:")
        print("Permissions can be represented as numbers using octal (base-8) format:")
        print("  r = 4  (binary 100)")
        print("  w = 2  (binary 010)")
        print("  x = 1  (binary 001)")
        
        print("\nFor each category (owner, group, others), you add the values:")
        print("  7 = rwx (4+2+1 = 7)")
        print("  6 = rw- (4+2+0 = 6)")
        print("  5 = r-x (4+0+1 = 5)")
        print("  4 = r-- (4+0+0 = 4)")
        print("  3 = -wx (0+2+1 = 3)")
        print("  2 = -w- (0+2+0 = 2)")
        print("  1 = --x (0+0+1 = 1)")
        print("  0 = --- (0+0+0 = 0)")
        
        print("\nCOMMON PERMISSION COMBINATIONS:")
        print("  644 (rw-r--r--): Regular files (owner can read/write, others can only read)")
        print("  755 (rwxr-xr-x): Scripts and programs (executable by everyone)")
        print("  600 (rw-------): Private files (only owner can read/write)")
        print("  700 (rwx------): Private scripts (only owner can read/write/execute)")
        print("  777 (rwxrwxrwx): Public files (everyone has full access - avoid for security)")
        
        input("\nPress Enter to continue...")
    
    def file_operations(self):
        """Simulate file operations to demonstrate permissions."""
        self.print_header("FILE OPERATIONS SIMULATION")
        
        print(f"Current user: {self.current_user}")
        print(f"User groups: {', '.join(self.users[self.current_user]['groups'])}")
        
        print("\nSelect a file to perform operations on:")
        file_list = list(self.file_system.keys())
        for i, filename in enumerate(file_list, 1):
            print(f"{i}. {filename}")
        
        try:
            choice = int(input("\nEnter file number: ")) - 1
            if choice < 0 or choice >= len(file_list):
                raise ValueError
            
            filename = file_list[choice]
            file_info = self.file_system[filename]
            
            self.print_header(f"OPERATIONS ON: {filename}")
            
            print(f"File: {filename}")
            print(f"Type: {file_info['type']}")
            print(f"Owner: {file_info['owner']}")
            print(f"Group: {file_info['group']}")
            
            # Get permissions in both formats
            octal_perm = file_info['permissions']
            rwx_perm = self.octal_to_rwx(octal_perm)
            
            print(f"Permissions (octal): {oct(octal_perm)[2:]}")
            print(f"Permissions (rwx): {rwx_perm}")
            
            # Break down permissions by user category
            owner_perm = rwx_perm[0:3]
            group_perm = rwx_perm[3:6]
            others_perm = rwx_perm[6:9]
            
            print(f"  Owner permissions: {owner_perm}")
            print(f"  Group permissions: {group_perm}")
            print(f"  Others permissions: {others_perm}")
            
            # Check if current user is owner
            is_owner = self.current_user == file_info['owner']
            
            # Check if current user is in the file's group
            in_group = file_info['group'] in self.users[self.current_user]['groups']
            
            # Determine which permission set applies
            if is_owner:
                applicable_perms = owner_perm
                user_category = "owner"
            elif in_group:
                applicable_perms = group_perm
                user_category = "group member"
            else:
                applicable_perms = others_perm
                user_category = "other user"
            
            print(f"\nAccess analysis for user '{self.current_user}':")
            print(f"- You are the {user_category} of this file")
            print(f"- Your applicable permissions are: {applicable_perms}")
            
            # Determine what operations are allowed
            can_read = 'r' in applicable_perms
            can_write = 'w' in applicable_perms
            can_execute = 'x' in applicable_perms
            
            print("\nAllowed operations:")
            print(f"- Read: {'✅ Yes' if can_read else '❌ No'}")
            print(f"- Write: {'✅ Yes' if can_write else '❌ No'}")
            print(f"- Execute: {'✅ Yes' if can_execute else '❌ No'}")
            
            # Offer operation choices
            print("\nWhat would you like to do?")
            print("1. Try to read the file")
            print("2. Try to modify the file")
            print("3. Try to execute the file")
            print("4. Change file permissions (chmod)")
            print("5. Back to main menu")
            
            operation = input("\nSelect operation (1-5): ")
            
            if operation == "1":
                # Read operation
                print("\nAttempting to read file...")
                time.sleep(1)
                
                if can_read:
                    print("✅ Permission granted!")
                    if file_info["type"] == "file":
                        print("\nFile contents:")
                        print("-" * 40)
                        print(file_info["content"])
                        print("-" * 40)
                    else:
                        print("\nDirectory contents:")
                        print("-" * 40)
                        for item in file_info["contents"]:
                            print(item)
                        print("-" * 40)
                else:
                    print("❌ Permission denied! You don't have read (r) permission.")
            
            elif operation == "2":
                # Write operation
                print("\nAttempting to modify file...")
                time.sleep(1)
                
                if can_write:
                    print("✅ Permission granted!")
                    if file_info["type"] == "file":
                        new_content = input("\nEnter new content: ")
                        self.file_system[filename]["content"] = new_content
                        print("File successfully modified.")
                    else:
                        print("Directory modification would involve adding or removing files.")
                        print("(Simplified for this simulation)")
                else:
                    print("❌ Permission denied! You don't have write (w) permission.")
            
            elif operation == "3":
                # Execute operation
                print("\nAttempting to execute file...")
                time.sleep(1)
                
                if file_info["type"] == "directory":
                    if can_execute:
                        print("✅ Permission granted!")
                        print("You can access this directory and its contents.")
                        print("(In Linux, 'x' permission on a directory allows you to access its contents)")
                    else:
                        print("❌ Permission denied! You don't have execute (x) permission.")
                        print("Cannot access this directory even if contents are readable.")
                else:
                    if can_execute:
                        print("✅ Permission granted!")
                        if filename.endswith('.sh'):
                            print("Executing shell script...")
                            print("\nOutput:")
                            print("-" * 40)
                            for line in file_info["content"].splitlines():
                                if line.startswith('#!'):
                                    continue
                                if line.startswith('echo'):
                                    print(line[5:].strip("'").strip('"'))
                            print("-" * 40)
                            print("Script executed successfully.")
                        else:
                            print("This file doesn't appear to be executable.")
                    else:
                        print("❌ Permission denied! You don't have execute (x) permission.")
            
            elif operation == "4":
                # Change permissions
                if is_owner or self.current_user == "root":
                    print("\nCurrent permissions (octal):", oct(file_info['permissions'])[2:])
                    print("Current permissions (rwx):", self.octal_to_rwx(file_info['permissions']))
                    
                    print("\nHow would you like to specify new permissions?")
                    print("1. Octal format (e.g., 755)")
                    print("2. Symbolic format (e.g., rwxr-xr-x)")
                    
                    perm_choice = input("\nSelect format (1-2): ")
                    
                    if perm_choice == "1":
                        new_perm = input("Enter new permissions in octal (e.g., 755): ")
                        try:
                            new_perm_octal = int(new_perm, 8)
                            self.file_system[filename]["permissions"] = new_perm_octal
                            print(f"✅ Permissions changed to {new_perm} ({self.octal_to_rwx(new_perm_octal)})")
                        except ValueError:
                            print("❌ Invalid octal permission format.")
                    
                    elif perm_choice == "2":
                        new_perm = input("Enter new permissions in rwx format (e.g., rwxr-xr-x): ")
                        if len(new_perm) == 9 and all(c in "rwx-" for c in new_perm):
                            new_perm_octal = 0
                            
                            # Calculate octal for owner
                            if "r" in new_perm[0:1]: new_perm_octal += 0o400
                            if "w" in new_perm[1:2]: new_perm_octal += 0o200
                            if "x" in new_perm[2:3]: new_perm_octal += 0o100
                            
                            # Calculate octal for group
                            if "r" in new_perm[3:4]: new_perm_octal += 0o40
                            if "w" in new_perm[4:5]: new_perm_octal += 0o20
                            if "x" in new_perm[5:6]: new_perm_octal += 0o10
                            
                            # Calculate octal for others
                            if "r" in new_perm[6:7]: new_perm_octal += 0o4
                            if "w" in new_perm[7:8]: new_perm_octal += 0o2
                            if "x" in new_perm[8:9]: new_perm_octal += 0o1
                            
                            self.file_system[filename]["permissions"] = new_perm_octal
                            print(f"✅ Permissions changed to {oct(new_perm_octal)[2:]} ({new_perm})")
                        else:
                            print("❌ Invalid rwx permission format. Must be 9 characters using only r, w, x, and -.")
                    else:
                        print("Invalid choice.")
                else:
                    print("❌ Permission denied! Only the owner or root can change permissions.")
            
        except (ValueError, IndexError):
            print("\n❌ Invalid selection.")
        
        input("\nPress Enter to continue...")
    
    def permission_calculator(self):
        """Interactive permission calculator."""
        self.print_header("PERMISSION CALCULATOR")
        
        print("This tool helps you convert between rwx and octal permission formats.\n")
        
        print("1. Convert from rwx to octal")
        print("2. Convert from octal to rwx")
        print("3. Interactive permission builder")
        print("4. Back to main menu")
        
        choice = input("\nSelect option (1-4): ")
        
        if choice == "1":
            rwx = input("\nEnter permissions in rwx format (e.g., rwxr-xr-x): ")
            if len(rwx) == 9 and all(c in "rwx-" for c in rwx):
                octal = 0
                for i in range(0, 9, 3):
                    value = 0
                    if rwx[i] == 'r': value += 4
                    if rwx[i+1] == 'w': value += 2
                    if rwx[i+2] == 'x': value += 1
                    octal = octal * 10 + value
                
                print(f"\nOctal equivalent: {octal}")
            else:
                print("\n❌ Invalid format. Must be 9 characters using only r, w, x, and -.")
        
        elif choice == "2":
            try:
                octal = input("\nEnter permissions in octal format (e.g., 755): ")
                if len(octal) == 3 and all(c in "01234567" for c in octal):
                    rwx = ""
                    for digit in octal:
                        d = int(digit)
                        rwx += "r" if d & 4 else "-"
                        rwx += "w" if d & 2 else "-"
                        rwx += "x" if d & 1 else "-"
                    
                    print(f"\nrwx equivalent: {rwx}")
                else:
                    print("\n❌ Invalid format. Must be 3 digits between 0-7.")
            except ValueError:
                print("\n❌ Invalid octal number.")
        
        elif choice == "3":
            self.print_header("INTERACTIVE PERMISSION BUILDER")
            
            # Initialize permissions
            owner_r = owner_w = owner_x = False
            group_r = group_w = group_x = False
            other_r = other_w = other_x = False
            
            while True:
                # Calculate current permissions
                octal = 0
                if owner_r: octal += 0o400
                if owner_w: octal += 0o200
                if owner_x: octal += 0o100
                if group_r: octal += 0o40
                if group_w: octal += 0o20
                if group_x: octal += 0o10
                if other_r: octal += 0o4
                if other_w: octal += 0o2
                if other_x: octal += 0o1
                
                rwx = ""
                rwx += "r" if owner_r else "-"
                rwx += "w" if owner_w else "-"
                rwx += "x" if owner_x else "-"
                rwx += "r" if group_r else "-"
                rwx += "w" if group_w else "-"
                rwx += "x" if group_x else "-"
                rwx += "r" if other_r else "-"
                rwx += "w" if other_w else "-"
                rwx += "x" if other_x else "-"
                
                print("\nCurrent Permissions:")
                print(f"Octal: {oct(octal)[2:]}")
                print(f"rwx: {rwx}")
                print("\nBreakdown:")
                print(f"Owner: {'r' if owner_r else '-'}{'w' if owner_w else '-'}{'x' if owner_x else '-'}")
                print(f"Group: {'r' if group_r else '-'}{'w' if group_w else '-'}{'x' if group_x else '-'}")
                print(f"Other: {'r' if other_r else '-'}{'w' if other_w else '-'}{'x' if other_x else '-'}")
                
                print("\nToggle permissions:")
                print("1. Owner read (r)")
                print("2. Owner write (w)")
                print("3. Owner execute (x)")
                print("4. Group read (r)")
                print("5. Group write (w)")
                print("6. Group execute (x)")
                print("7. Other read (r)")
                print("8. Other write (w)")
                print("9. Other execute (x)")
                print("10. Common presets")
                print("11. Back to calculator menu")
                
                toggle = input("\nSelect permission to toggle (1-11): ")
                
                if toggle == "1": owner_r = not owner_r
                elif toggle == "2": owner_w = not owner_w
                elif toggle == "3": owner_x = not owner_x
                elif toggle == "4": group_r = not group_r
                elif toggle == "5": group_w = not group_w
                elif toggle == "6": group_x = not group_x
                elif toggle == "7": other_r = not other_r
                elif toggle == "8": other_w = not other_w
                elif toggle == "9": other_x = not other_x
                elif toggle == "10":
                    print("\nCommon permission presets:")
                    print("1. 644 (rw-r--r--): Regular files")
                    print("2. 755 (rwxr-xr-x): Executable files")
                    print("3. 600 (rw-------): Private files")
                    print("4. 700 (rwx------): Private scripts")
                    print("5. 777 (rwxrwxrwx): Full access to everyone")
                    
                    preset = input("\nSelect preset (1-5): ")
                    
                    if preset == "1":  # 644
                        owner_r, owner_w, owner_x = True, True, False
                        group_r, group_w, group_x = True, False, False
                        other_r, other_w, other_x = True, False, False
                    elif preset == "2":  # 755
                        owner_r, owner_w, owner_x = True, True, True
                        group_r, group_w, group_x = True, False, True
                        other_r, other_w, other_x = True, False, True
                    elif preset == "3":  # 600
                        owner_r, owner_w, owner_x = True, True, False
                        group_r, group_w, group_x = False, False, False
                        other_r, other_w, other_x = False, False, False
                    elif preset == "4":  # 700
                        owner_r, owner_w, owner_x = True, True, True
                        group_r, group_w, group_x = False, False, False
                        other_r, other_w, other_x = False, False, False
                    elif preset == "5":  # 777
                        owner_r, owner_w, owner_x = True, True, True
                        group_r, group_w, group_x = True, True, True
                        other_r, other_w, other_x = True, True, True
                elif toggle == "11":
                    break
        
        input("\nPress Enter to continue...")
    
    def chmod_tutorial(self):
        """Tutorial on the chmod command."""
        self.print_header("CHMOD COMMAND TUTORIAL")
        
        print("The chmod command changes file permissions in Linux.\n")
        
        print("CHMOD SYNTAX:")
        print("  chmod [options] mode file")
        
        print("\nCHMOD MODES:")
        print("1. Octal notation:")
        print("   chmod 755 file.txt")
        print("   (rwxr-xr-x: owner can read/write/execute, others can read/execute)")
        
        print("\n2. Symbolic notation:")
        print("   chmod u=rwx,g=rx,o=rx file.txt")
        print("   (Same as 755)")
        
        print("\n   chmod u+x file.txt")
        print("   (Add execute permission for owner)")
        
        print("\n   chmod go-w file.txt")
        print("   (Remove write permission from group and others)")
        
        print("\nWHO SYMBOLS:")
        print("  u = user (owner)")
        print("  g = group")
        print("  o = others (everyone else)")
        print("  a = all (equivalent to ugo)")
        
        print("\nOPERATION SYMBOLS:")
        print("  + = add permission")
        print("  - = remove permission")
        print("  = = set exact permission")
        
        print("\nPERMISSION SYMBOLS:")
        print("  r = read permission")
        print("  w = write permission")
        print("  x = execute permission")
        
        print("\nEXAMPLES:")
        print("  chmod 644 file.txt           # Set to rw-r--r--")
        print("  chmod u+x file.txt           # Add execute for owner")
        print("  chmod a+r file.txt           # Add read for everyone")
        print("  chmod u+rwx,go-rwx file.txt  # Set to rwx------")
        print("  chmod -R 755 directory       # Recursively set permissions on a directory")
        
        input("\nPress Enter to continue...")
    
    def special_permissions(self):
        """Explain special permissions (setuid, setgid, sticky bit)."""
        self.print_header("SPECIAL PERMISSIONS")
        
        print("Beyond basic rwx permissions, Linux has three special permissions:\n")
        
        print("1. SETUID (Set User ID) - 4000")
        print("   • When set on an executable file, it runs with the privileges of the file owner")
        print("   • In symbolic notation, shown as 's' in the owner execute position")
        print("   • Example: chmod 4755 file (rwsr-xr-x)")
        print("   • Real-world example: The 'passwd' command has the setuid bit set so users")
        print("     can change their password, which requires modifying system files")
        
        print("\n2. SETGID (Set Group ID) - 2000")
        print("   • On files: Executes with the privileges of the file's group")
        print("   • On directories: New files created in the directory inherit the directory's group")
        print("   • In symbolic notation, shown as 's' in the group execute position")
        print("   • Example: chmod 2755 file (rwxr-sr-x)")
        print("   • Real-world example: Used on shared directories to ensure all files in a")
        print("     project directory belong to the project group regardless of who creates them")
        
        print("\n3. STICKY BIT - 1000")
        print("   • Primarily used on directories")
        print("   • Prevents users from deleting files owned by other users in that directory")
        print("   • In symbolic notation, shown as 't' in the others execute position")
        print("   • Example: chmod 1777 directory (rwxrwxrwt)")
        print("   • Real-world example: The /tmp directory has the sticky bit set so users")
        print("     can create files but cannot delete files owned by others")
        
        print("\nCOMBINING SPECIAL PERMISSIONS:")
        print("You can combine these bits with regular permissions:")
        print("  chmod 4755 file  # setuid + rwxr-xr-x")
        print("  chmod 2755 file  # setgid + rwxr-xr-x")
        print("  chmod 1777 dir   # sticky bit + rwxrwxrwx")
        print("  chmod 6755 file  # setuid + setgid + rwxr-xr-x")
        
        print("\nSPECIAL PERMISSION RISKS:")
        print("• Setuid programs run with elevated privileges and can be security risks")
        print("• Always be cautious when using special permissions")
        print("• The full 4-digit octal notation includes these special permissions")
        print("  (e.g., 4755 where '4' is the setuid bit)")
        
        input("\nPress Enter to continue...")
    
    def visual_permission_simulation(self):
        """Visual simulation of how permissions work."""
        self.print_header("VISUAL PERMISSION SIMULATION")
        
        print("This simulation will help you visualize how Linux permissions work.")
        print("We'll simulate different permission scenarios and show their effects.\n")
        
        # Demo scenario 1: Basic file access
        print("SCENARIO 1: Basic File Access")
        print("-" * 50)
        print("File: important_data.txt")
        print("Owner: alice")
        print("Group: users")
        print("Content: 'This is important data that should be protected'")
        
        print("\nLet's see how different permissions affect access:")
        
        permissions = [
            (0o600, "rw-------", "Private (owner only)"),
            (0o640, "rw-r-----", "Group readable"),
            (0o644, "rw-r--r--", "World readable"),
            (0o660, "rw-rw----", "Group writable"),
            (0o666, "rw-rw-rw-", "World writable")
        ]
        
        for perm_octal, perm_rwx, desc in permissions:
            print(f"\n{desc} ({perm_octal:o}, {perm_rwx}):")
            
            # Simulate file access for different users
            for user in ["alice", "bob", "carol"]:
                # Determine user type
                if user == "alice":
                    user_type = "owner"
                    applicable_perm = perm_rwx[0:3]
                elif user in self.users and "users" in self.users[user]["groups"]:
                    user_type = "group member"
                    applicable_perm = perm_rwx[3:6]
                else:
                    user_type = "other"
                    applicable_perm = perm_rwx[6:9]
                
                # Check permissions
                can_read = 'r' in applicable_perm
                can_write = 'w' in applicable_perm
                
                # Display results
                print(f"  {user} ({user_type}):")
                print(f"    Read:  {'✅' if can_read else '❌'}")
                print(f"    Write: {'✅' if can_write else '❌'}")
            
            input("  Press Enter to continue...")
        
        # Demo scenario 2: Directory permissions
        self.print_header("VISUAL PERMISSION SIMULATION (continued)")
        print("SCENARIO 2: Directory Permissions")
        print("-" * 50)
        print("Directory: /projects")
        print("Owner: alice")
        print("Group: developers")
        print("Contains: project_files.txt, code.py")
        
        print("\nDirectory permissions are more complex:")
        print("• 'r' allows listing directory contents")
        print("• 'w' allows creating/deleting files in the directory")
        print("• 'x' allows accessing the directory and its contents")
        
        dir_permissions = [
            (0o700, "rwx------", "Private directory"),
            (0o750, "rwxr-x---", "Group accessible"),
            (0o755, "rwxr-xr-x", "World accessible"),
            (0o770, "rwxrwx---", "Group writable"),
            (0o777, "rwxrwxrwx", "World writable")
        ]
        
        for perm_octal, perm_rwx, desc in dir_permissions:
            print(f"\n{desc} ({perm_octal:o}, {perm_rwx}):")
            
            # Simulate directory access for different users
            for user in ["alice", "bob", "carol"]:
                # Determine user type
                if user == "alice":
                    user_type = "owner"
                    applicable_perm = perm_rwx[0:3]
                elif user in self.users and "developers" in self.users[user]["groups"]:
                    user_type = "group member"
                    applicable_perm = perm_rwx[3:6]
                else:
                    user_type = "other"
                    applicable_perm = perm_rwx[6:9]
                
                # Check permissions
                can_list = 'r' in applicable_perm
                can_create = 'w' in applicable_perm
                can_access = 'x' in applicable_perm
                
                # Display results
                print(f"  {user} ({user_type}):")
                print(f"    List contents:   {'✅' if can_list else '❌'}")
                print(f"    Create files:    {'✅' if can_create else '❌'}")
                print(f"    Access contents: {'✅' if can_access else '❌'}")
                if can_list and not can_access:
                    print(f"    ⚠️ Can list filenames but can't access them without 'x'")
            
            input("  Press Enter to continue...")
        
        # Demo scenario 3: Execute permissions
        self.print_header("VISUAL PERMISSION SIMULATION (continued)")
        print("SCENARIO 3: Execute Permissions")
        print("-" * 50)
        print("File: backup.sh (Shell script)")
        print("Owner: alice")
        print("Group: users")
        print("Content: '#!/bin/bash\necho Backing up files...'")
        
        print("\nExecute permissions determine who can run a script:")
        
        exec_permissions = [
            (0o600, "rw-------", "No execute permission"),
            (0o700, "rwx------", "Owner can execute"),
            (0o750, "rwxr-x---", "Owner and group can execute"),
            (0o755, "rwxr-xr-x", "Everyone can execute")
        ]
        
        for perm_octal, perm_rwx, desc in exec_permissions:
            print(f"\n{desc} ({perm_octal:o}, {perm_rwx}):")
            
            # Simulate script execution for different users
            for user in ["alice", "bob", "carol"]:
                # Determine user type
                if user == "alice":
                    user_type = "owner"
                    applicable_perm = perm_rwx[0:3]
                elif user in self.users and "users" in self.users[user]["groups"]:
                    user_type = "group member"
                    applicable_perm = perm_rwx[3:6]
                else:
                    user_type = "other"
                    applicable_perm = perm_rwx[6:9]
                
                # Check permissions
                can_read = 'r' in applicable_perm
                can_execute = 'x' in applicable_perm
                
                # Display results
                print(f"  {user} ({user_type}):")
                if can_execute:
                    print(f"    Execute: ✅ Can run the script")
                else:
                    if can_read:
                        print(f"    Execute: ❌ Can read but not execute the script")
                    else:
                        print(f"    Execute: ❌ Cannot access or execute the script")
            
            input("  Press Enter to continue...")
    
    def practical_examples(self):
        """Show practical examples of Linux permissions."""
        self.print_header("PRACTICAL PERMISSION EXAMPLES")
        
        examples = [
            {
                "title": "Personal Home Directory",
                "path": "/home/alice",
                "type": "directory",
                "permissions": 0o700,  # rwx------
                "explanation": [
                    "• Owner has full control (rwx)",
                    "• No access for group or others",
                    "• Keeps personal files private from other users",
                    "• Common setting for home directories"
                ]
            },
            {
                "title": "Configuration File",
                "path": "/home/alice/.config/app.conf",
                "type": "file",
                "permissions": 0o600,  # rw-------
                "explanation": [
                    "• Owner can read and write",
                    "• No access for group or others",
                    "• Protects sensitive configuration data",
                    "• Often used for files with passwords or API keys"
                ]
            },
            {
                "title": "Shell Script",
                "path": "/home/alice/scripts/backup.sh",
                "type": "file",
                "permissions": 0o755,  # rwxr-xr-x
                "explanation": [
                    "• Owner has full control (rwx)",
                    "• Group and others can read and execute",
                    "• Allows others to run the script but not modify it",
                    "• Common for commands and utilities"
                ]
            },
            {
                "title": "Shared Project Directory",
                "path": "/projects/website",
                "type": "directory",
                "permissions": 0o770,  # rwxrwx---
                "explanation": [
                    "• Owner and group members have full control",
                    "• No access for others",
                    "• Enables team collaboration while restricting outside access",
                    "• Common for development projects"
                ]
            },
            {
                "title": "Public HTML Directory",
                "path": "/var/www/html",
                "type": "directory",
                "permissions": 0o755,  # rwxr-xr-x
                "explanation": [
                    "• Owner has full control",
                    "• Group and others can read and traverse",
                    "• Web server needs to read files and access directories",
                    "• Prevents unauthorized modifications"
                ]
            },
            {
                "title": "Public Website File",
                "path": "/var/www/html/index.html",
                "type": "file",
                "permissions": 0o644,  # rw-r--r--
                "explanation": [
                    "• Owner can read and write",
                    "• Group and others can only read",
                    "• Web server needs to read but not modify files",
                    "• Standard permission for web content"
                ]
            },
            {
                "title": "Temporary Directory",
                "path": "/tmp",
                "type": "directory",
                "permissions": 0o1777,  # rwxrwxrwt (sticky bit)
                "explanation": [
                    "• Everyone has full access (rwx)",
                    "• Sticky bit (t) is set",
                    "• Users can create files but can't delete files owned by others",
                    "• Prevents users from deleting each other's temporary files"
                ]
            }
        ]
        
        for example in examples:
            print(f"{example['title']}")
            print("-" * 50)
            print(f"Path: {example['path']}")
            print(f"Type: {example['type']}")
            
            # Format permissions
            perm_octal = example['permissions']
            perm_rwx = self.octal_to_rwx(perm_octal)
            print(f"Permissions: {oct(perm_octal)[2:]} ({perm_rwx})")
            
            print("\nExplanation:")
            for line in example['explanation']:
                print(line)
            
            print()
            input("Press Enter to continue...")
            self.print_header("PRACTICAL PERMISSION EXAMPLES (continued)")
    
    def menu(self):
        """Display main menu and handle user choices."""
        while True:
            self.print_header("LINUX PERMISSIONS SIMULATOR")
            
            print(f"Current user: {self.current_user}")
            print(f"Groups: {', '.join(self.users[self.current_user]['groups'])}")
            
            print("\nMAIN MENU:")
            print("1. Switch User")
            print("2. List Files (ls -l)")
            print("3. Explain Permissions (rwx and numeric)")
            print("4. File Operations (Read/Write/Execute)")
            print("5. Permission Calculator")
            print("6. chmod Command Tutorial")
            print("7. Special Permissions (setuid, setgid, sticky bit)")
            print("8. Visual Permission Simulation")
            print("9. Practical Examples")
            print("10. Exit")
            
            choice = input("\nSelect an option (1-10): ")
            
            if choice == '1':
                self.switch_user()
            elif choice == '2':
                self.list_files()
            elif choice == '3':
                self.explain_permissions()
            elif choice == '4':
                self.file_operations()
            elif choice == '5':
                self.permission_calculator()
            elif choice == '6':
                self.chmod_tutorial()
            elif choice == '7':
                self.special_permissions()
            elif choice == '8':
                self.visual_permission_simulation()
            elif choice == '9':
                self.practical_examples()
            elif choice == '10':
                self.print_header("Goodbye!")
                print("Thanks for using the Linux Permissions Simulator.")
                print("Remember: Understanding permissions is crucial for Linux security and administration.")
                time.sleep(2)
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 10.")
                time.sleep(1)

if __name__ == "__main__":
    simulator = LinuxPermissionsSimulator()
    simulator.menu()
