import os
import time
import sys
import random
from datetime import datetime

class AccessControlSimulator:
    def __init__(self):
        # User database with attributes
        self.users = {
            # Username: {attributes}
            "alice": {
                "password": "alice123", 
                "role": "manager",
                "department": "finance",
                "security_clearance": "confidential",
                "hire_date": "2018-05-15",
                "transfer_limit": 10000,
                "owner_of": ["financial_report.xlsx", "budget_2024.docx"]
            },
            "bob": {
                "password": "bob123", 
                "role": "employee",
                "department": "finance",
                "security_clearance": "restricted",
                "hire_date": "2020-11-03", 
                "transfer_limit": 1000,
                "owner_of": ["expense_report.xlsx"]
            },
            "carol": {
                "password": "carol123", 
                "role": "admin",
                "department": "it",
                "security_clearance": "secret",
                "hire_date": "2015-02-28",
                "transfer_limit": 5000,
                "owner_of": ["system_architecture.pdf", "network_diagram.pdf"]
            },
            "dave": {
                "password": "dave123", 
                "role": "employee",
                "department": "hr",
                "security_clearance": "restricted",
                "hire_date": "2021-07-10",
                "transfer_limit": 500,
                "owner_of": ["onboarding_checklist.docx"]
            }
        }
        
        # Resources with properties
        self.resources = {
            # Resource: {properties}
            "financial_report.xlsx": {
                "owner": "alice",
                "shared_with": ["bob"],
                "classification": "confidential",
                "department": "finance",
                "type": "financial_document"
            },
            "budget_2024.docx": {
                "owner": "alice",
                "shared_with": [],
                "classification": "confidential",
                "department": "finance",
                "type": "financial_document"
            },
            "expense_report.xlsx": {
                "owner": "bob",
                "shared_with": ["alice"],
                "classification": "restricted",
                "department": "finance",
                "type": "financial_document"
            },
            "system_architecture.pdf": {
                "owner": "carol",
                "shared_with": [],
                "classification": "secret",
                "department": "it",
                "type": "technical_document"
            },
            "network_diagram.pdf": {
                "owner": "carol",
                "shared_with": [],
                "classification": "secret",
                "department": "it",
                "type": "technical_document"
            },
            "employee_data.csv": {
                "owner": "system",
                "shared_with": [],
                "classification": "confidential",
                "department": "hr",
                "type": "personnel_record"
            },
            "company_policy.pdf": {
                "owner": "system",
                "shared_with": ["all"],
                "classification": "public",
                "department": "hr",
                "type": "policy_document"
            },
            "onboarding_checklist.docx": {
                "owner": "dave",
                "shared_with": [],
                "classification": "restricted",
                "department": "hr",
                "type": "procedure_document"
            }
        }
        
        # Role-based permissions
        self.role_permissions = {
            "employee": {
                "financial_document": ["read"],
                "technical_document": [],
                "personnel_record": [],
                "policy_document": ["read"],
                "procedure_document": ["read"]
            },
            "manager": {
                "financial_document": ["read", "write", "share"],
                "technical_document": ["read"],
                "personnel_record": ["read"],
                "policy_document": ["read"],
                "procedure_document": ["read", "write"]
            },
            "admin": {
                "financial_document": ["read", "write"],
                "technical_document": ["read", "write", "share", "delete"],
                "personnel_record": ["read", "write"],
                "policy_document": ["read", "write", "share"],
                "procedure_document": ["read", "write", "share"]
            }
        }
        
        # Security classification access levels
        self.clearance_levels = {
            "public": 0,
            "restricted": 1,
            "confidential": 2,
            "secret": 3,
            "top_secret": 4
        }
        
        self.current_user = None
        self.business_hours = (9, 17)  # 9 AM to 5 PM
    
    def clear_screen(self):
        """Clear the terminal screen."""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title):
        """Print a formatted header."""
        self.clear_screen()
        width = 70
        print("=" * width)
        print(f"{title:^{width}}")
        print("=" * width)
        print()
    
    def slow_print(self, text, delay=0.02):
        """Print text with a typing effect."""
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)
        print()
    
    def login(self):
        """Authenticate a user."""
        self.print_header("USER AUTHENTICATION")
        
        print("Before access control can be applied, users must authenticate.")
        print("This proves they are who they claim to be.\n")
        
        username = input("Username: ")
        password = input("Password: ")
        
        if username in self.users and self.users[username]["password"] == password:
            self.current_user = username
            print(f"\n✅ Authentication successful! Welcome, {username}.")
            time.sleep(1)
            return True
        else:
            print("\n❌ Authentication failed. Invalid username or password.")
            time.sleep(1)
            return False
    
    def logout(self):
        """Log out the current user."""
        self.current_user = None
        print("\nYou have been logged out.")
        time.sleep(1)
    
    def simulate_dac(self):
        """Simulate Discretionary Access Control."""
        self.print_header("DISCRETIONARY ACCESS CONTROL (DAC)")
        
        if not self.current_user:
            print("You need to log in first.")
            time.sleep(1)
            return
        
        print("In DAC, the OWNER of a resource controls who can access it.")
        print("Like when you share a Google Doc with specific people.\n")
        
        # Show resources owned by the current user
        user_resources = [r for r in self.resources if self.resources[r]["owner"] == self.current_user]
        
        if not user_resources:
            print(f"{self.current_user} doesn't own any resources.")
            input("\nPress Enter to continue...")
            return
            
        print(f"Resources owned by {self.current_user}:")
        for i, resource in enumerate(user_resources, 1):
            shared_with = ", ".join(self.resources[resource]["shared_with"]) if self.resources[resource]["shared_with"] else "No one"
            print(f"{i}. {resource} (Currently shared with: {shared_with})")
        
        try:
            resource_idx = int(input("\nSelect a resource to manage sharing (number): ")) - 1
            if resource_idx < 0 or resource_idx >= len(user_resources):
                raise ValueError
            
            selected_resource = user_resources[resource_idx]
            
            print(f"\nManaging access for: {selected_resource}")
            print("1. Share with another user")
            print("2. Remove user access")
            print("3. Back to menu")
            
            action = input("\nSelect action (number): ")
            
            if action == "1":
                # Show users to share with
                other_users = [u for u in self.users if u != self.current_user]
                for i, user in enumerate(other_users, 1):
                    print(f"{i}. {user}")
                
                user_idx = int(input("\nShare with which user (number): ")) - 1
                if user_idx < 0 or user_idx >= len(other_users):
                    raise ValueError
                
                share_with = other_users[user_idx]
                
                # Add user to shared_with list if not already there
                if share_with not in self.resources[selected_resource]["shared_with"]:
                    self.resources[selected_resource]["shared_with"].append(share_with)
                    print(f"\n✅ Successfully shared {selected_resource} with {share_with}")
                else:
                    print(f"\nℹ️ {share_with} already has access to this resource.")
                
            elif action == "2":
                # Show users to remove
                shared_users = self.resources[selected_resource]["shared_with"]
                
                if not shared_users:
                    print("\nThis resource isn't shared with anyone.")
                else:
                    for i, user in enumerate(shared_users, 1):
                        print(f"{i}. {user}")
                    
                    user_idx = int(input("\nRemove which user (number): ")) - 1
                    if user_idx < 0 or user_idx >= len(shared_users):
                        raise ValueError
                    
                    remove_user = shared_users[user_idx]
                    self.resources[selected_resource]["shared_with"].remove(remove_user)
                    print(f"\n✅ Successfully removed {remove_user}'s access to {selected_resource}")
                    
        except (ValueError, IndexError):
            print("\n❌ Invalid selection.")
        
        input("\nPress Enter to continue...")
    
    def simulate_mac(self):
        """Simulate Mandatory Access Control."""
        self.print_header("MANDATORY ACCESS CONTROL (MAC)")
        
        if not self.current_user:
            print("You need to log in first.")
            time.sleep(1)
            return
        
        print("In MAC, the SYSTEM enforces access based on security levels.")
        print("Like in government systems with classified documents.\n")
        
        user_clearance = self.users[self.current_user]["security_clearance"]
        user_clearance_level = self.clearance_levels[user_clearance]
        
        print(f"User: {self.current_user}")
        print(f"Security Clearance: {user_clearance.upper()}")
        print(f"Clearance Level: {user_clearance_level}")
        print("\nHierarchy: Public < Restricted < Confidential < Secret < Top Secret")
        
        print("\nAttempting to access resources based on security clearance:")
        
        for resource, properties in self.resources.items():
            resource_classification = properties["classification"]
            resource_level = self.clearance_levels[resource_classification]
            
            sys.stdout.write(f"Accessing {resource} (Classification: {resource_classification.upper()})... ")
            sys.stdout.flush()
            time.sleep(0.5)
            
            if user_clearance_level >= resource_level:
                print("✅ ACCESS GRANTED")
            else:
                print("❌ ACCESS DENIED - Insufficient clearance")
        
        print("\nIn MAC, even if you're the owner, you cannot override the security policy.")
        print("The system, not the user, enforces access based on security labels.")
        
        input("\nPress Enter to continue...")
    
    def simulate_rbac(self):
        """Simulate Role-Based Access Control."""
        self.print_header("ROLE-BASED ACCESS CONTROL (RBAC)")
        
        if not self.current_user:
            print("You need to log in first.")
            time.sleep(1)
            return
        
        print("In RBAC, access is determined by your ROLE in the organization.")
        print("Like in a hospital where doctors, nurses, and staff have different access.\n")
        
        user_role = self.users[self.current_user]["role"]
        
        print(f"User: {self.current_user}")
        print(f"Role: {user_role.upper()}")
        
        # Show available resources and check permissions
        print("\nResource access based on your role:")
        
        for resource, properties in self.resources.items():
            resource_type = properties["type"]
            
            allowed_actions = self.role_permissions[user_role][resource_type]
            
            if allowed_actions:
                permission_str = ", ".join(allowed_actions)
                print(f"📄 {resource} - ✅ CAN {permission_str}")
            else:
                print(f"📄 {resource} - ❌ NO ACCESS")
        
        print("\nIn RBAC, permissions are assigned to roles, not individual users.")
        print("When your role changes, your access changes automatically.")
        
        input("\nPress Enter to continue...")
    
    def simulate_abac(self):
        """Simulate Attribute-Based Access Control."""
        self.print_header("ATTRIBUTE-BASED ACCESS CONTROL (ABAC)")
        
        if not self.current_user:
            print("You need to log in first.")
            time.sleep(1)
            return
        
        print("In ABAC, access is determined by MULTIPLE ATTRIBUTES.")
        print("Like a bank that checks user, time, location, and amount for transfers.\n")
        
        # Get current hour for time-based decisions
        current_hour = datetime.now().hour
        within_business_hours = self.business_hours[0] <= current_hour < self.business_hours[1]
        
        # Set up a transfer scenario
        print(f"User: {self.current_user}")
        print(f"Department: {self.users[self.current_user]['department']}")
        print(f"Role: {self.users[self.current_user]['role']}")
        print(f"Current time: {current_hour}:00")
        print(f"Business hours: {self.business_hours[0]}:00 - {self.business_hours[1]}:00")
        print(f"User's transfer limit: ${self.users[self.current_user]['transfer_limit']}")
        
        print("\nSimulating a financial transfer with multiple attribute checks:")
        
        transfer_amount = int(input("\nEnter transfer amount ($): "))
        
        # Start the multi-attribute check process
        print("\nPerforming attribute-based access control checks...")
        
        # 1. Check user's department
        print("1. Checking user department...", end=" ")
        time.sleep(0.7)
        
        if self.users[self.current_user]['department'] == 'finance':
            print("✅ PASS - User is in finance department")
            dept_check = True
        else:
            print("⚠️ WARNING - User is not in finance department")
            dept_check = False
        
        # 2. Check business hours
        print("2. Checking if within business hours...", end=" ")
        time.sleep(0.7)
        
        if within_business_hours:
            print("✅ PASS - Within business hours")
            time_check = True
        else:
            print("❌ FAIL - Outside business hours")
            time_check = False
        
        # 3. Check transfer limit
        print("3. Checking transfer amount limit...", end=" ")
        time.sleep(0.7)
        
        if transfer_amount <= self.users[self.current_user]['transfer_limit']:
            print("✅ PASS - Within user's transfer limit")
            amount_check = True
        else:
            print("❌ FAIL - Exceeds user's transfer limit")
            amount_check = False
        
        # 4. Make final decision
        print("\nFinal decision based on multiple attributes:")
        time.sleep(1)
        
        # Different rule combinations based on department
        if self.users[self.current_user]['department'] == 'finance':
            # Finance department needs to pass time and amount checks
            if time_check and amount_check:
                print("✅ TRANSFER APPROVED - All required attributes passed")
            else:
                failed = []
                if not time_check: failed.append("outside business hours")
                if not amount_check: failed.append("exceeds transfer limit")
                
                print(f"❌ TRANSFER DENIED - Failed checks: {', '.join(failed)}")
        else:
            # Non-finance departments are more restricted
            if time_check and amount_check and self.users[self.current_user]['role'] == 'manager':
                print("✅ TRANSFER APPROVED - Manager approval for non-finance department")
            else:
                print("❌ TRANSFER DENIED - Non-finance users must be managers and pass all other checks")
        
        print("\nIn ABAC, many different attributes can affect the access decision.")
        print("The same user might get different access depending on time, location,")
        print("device, resource properties, and other contextual factors.")
        
        input("\nPress Enter to continue...")
    
    def show_comparison(self):
        """Show a comparison of the four access control models."""
        self.print_header("COMPARISON OF ACCESS CONTROL MODELS")
        
        print("Here's a side-by-side comparison of the four access control models:\n")
        
        comparison = [
            ["Type", "Who Decides?", "Key Benefit", "Key Limitation"],
            ["DAC", "Resource owner", "Flexibility", "Security depends on users"],
            ["MAC", "System/policy", "Strong security", "Rigid, administrative overhead"],
            ["RBAC", "System based on roles", "Simplified administration", "Complex role structures"],
            ["ABAC", "Rules engine", "Contextual decisions", "Complex to implement"]
        ]
        
        # Calculate column widths
        col_widths = [max(len(row[i]) for row in comparison) for i in range(len(comparison[0]))]
        
        # Print table with proper formatting
        for i, row in enumerate(comparison):
            formatted_row = " | ".join(f"{cell:{col_widths[j]}}" for j, cell in enumerate(row))
            print(formatted_row)
            
            # Print separator after header
            if i == 0:
                print("-" * sum(col_widths) + "-" * (len(col_widths) * 3 - 1))
        
        print("\nWhich is best? It depends on your organization's needs:")
        print("• Small teams often use DAC for simplicity and collaboration")
        print("• Government and military prefer MAC for strict security")
        print("• Most businesses use RBAC for a balance of security and usability")
        print("• Complex security needs may require ABAC or hybrid approaches")
        
        input("\nPress Enter to continue...")
    
    def menu(self):
        """Display main menu and handle user choices."""
        while True:
            self.print_header("ACCESS CONTROL SIMULATION")
            
            # Show login status
            if self.current_user:
                print(f"Logged in as: {self.current_user} ({self.users[self.current_user]['role']})")
            else:
                print("Status: Not logged in")
            
            print("\nSelect an option:")
            print("1. Login")
            print("2. Logout")
            print("3. Simulate Discretionary Access Control (DAC)")
            print("4. Simulate Mandatory Access Control (MAC)")
            print("5. Simulate Role-Based Access Control (RBAC)")
            print("6. Simulate Attribute-Based Access Control (ABAC)")
            print("7. Compare Access Control Models")
            print("8. Exit")
            
            choice = input("\nEnter your choice (1-8): ")
            
            if choice == '1':
                self.login()
            elif choice == '2':
                self.logout()
            elif choice == '3':
                self.simulate_dac()
            elif choice == '4':
                self.simulate_mac()
            elif choice == '5':
                self.simulate_rbac()
            elif choice == '6':
                self.simulate_abac()
            elif choice == '7':
                self.show_comparison()
            elif choice == '8':
                self.print_header("Thank You!")
                print("Remember: Authentication proves who you are.")
                print("Access control determines what you're allowed to do.")
                time.sleep(2)
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 8.")
                time.sleep(1)

if __name__ == "__main__":
    simulator = AccessControlSimulator()
    simulator.menu()
